/**
 * Created by HUCC on 2018/1/14.
 */
//初始化区域滚动效果
mui(".mui-scroll-wrapper").scroll({
  indicators:false,//关闭滚动条
});

//初始化轮播图
mui(".mui-slider").slider({
  interval:1000
});